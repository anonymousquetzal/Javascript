// ¿Qué es JS?
// Es un lenguaje de programación orientado a web para 
// tener páginas dinámicas
/*
    * JS es interpretado - Dinámico 
    * Multiparadigma
    * Inferencia de tipos
    * Compatibilidad hacia atrás
    * Key sensitive
    * camelCase (userName)
*/




// Por qué aprende JS?
/*
    * Desarrollo web
    * Desarrollo mobile
    * Desarrollo desktop
    * Backend 
    * IoT 
*/



// Este es un comentario de una sola línea
/* 
    Soy un comentario
    multi 
    linea
*/



// Tipos de dato --------------------
// Primitos
40;
"Hola, soy una cadena de texto"
'Hola soy un texto con comilla simple' 
`Hola soy un texto con intepolación ${nombre}`
true //boleanos
false //boleanos
null // El dato no existe
undefined // El dato aún no se ha guardado

// Otros tipos o de tipo objeto
[1,2,3]; //Arrays
{name: "Eduardo"} //Objecto


//Sentecias -------------------------
//Una sentencia es un bloque de código que se divider por ;
// el ; no es obligatorio pero si recomendado para divir instrunciones
nombre = "Eduardo";