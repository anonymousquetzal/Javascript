let person = {
    name: 'Eduardo',
    job: 'UI Developer',
    sayHello(name){
        console.log("Hola "+name);
    }
}
person.sayHello("Lucía");