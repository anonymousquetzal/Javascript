let userName = "eduardoMep";
console.log(userName);
console.log("Hola curso de de Academik");
console.log(23);