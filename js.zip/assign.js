// Asignación sencilla --------
let number1 = 10
console.log(number1);

// Asignación de automsuma --------
let number2 = 5;
// number2 = number2 + 10;
number2 +=  10;
console.log(number2);

// Asignación de autoresta --------
let number3 = 5;
// number2 = number2 - 10;
number3 -=  10;
console.log(number3);

// Asignación de automultiplicación --------
let number4 = 5;
// number2 = number2 * 10;
number4 *=  10;
console.log(number4);


// Asignación de división --------
let number5 = 5;
// number2 = number2 / 10;
number5 /=  10;
console.log(number5);