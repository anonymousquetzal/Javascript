//FUNCIONES---------------------
// Bloque de código reutilizable

//Procedimiento --------
// Solo realiza una acción, no retorna nada
function sayHello(name='Desconocido'){
    console.log("Hola " + name);
}
sayHello('Eduardo');
sayHello();

//Función ----------
// Solo retorna un valor o resultado
function returnHello(name='Desconocido'){
    return "Hola " + name
}
console.log(returnHello("Eduardo"));


//Funciones expresivas y declarativas
//Declarativa
function saySomething(){
    console.log("Estamos viendo funciones")
}
saySomething()
//Expresiva
let saySomething = function(){
    console.log("Estamos viendo funciones")
}
saySomething()


//Funciones de flecha ----------
let saySomething = () => console.log("Estamos viendo funciones con flecha")
saySomething();

let sum = (n1,n2) => {
    console.log(n1+n2)
}; 
sum(2,3);


// Self invoked functions
(function sayHello(){
    console.log("Hola, me activé sola");
})();


