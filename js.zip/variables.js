// Variables en js -----------------------

// Var asigna de manera global (No es muy recomendado utilizar var)
var userName = "eduardoMep";

// Se asigna solo para un ambiente
let password = "123";

// No pueden cambiar en tipo de ejecuación
// En ocasiones se escribre en mayus o bien con camelCase
const COUNTRY = "gt"; 
const PI = 3.1416;
const myName = "Eduardo";
COUNTRY = "usa"; // Esto daría error