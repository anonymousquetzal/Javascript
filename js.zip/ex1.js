var firstName = "Eduardo";
let lastName = "Peñate";

function sayHello(firstName, lastName){
    console.log(`${firstName} ${lastName}`);
}

sayHello(firstName,lastName);