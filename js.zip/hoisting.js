userName = "ePenate"
console.log(userName);
var userName = "eduardoMep";
console.log(userName);



// var userName;
// userName = "ePenate"
// console.log(userName);
// userName = "eduardoMep";
// console.log(userName);