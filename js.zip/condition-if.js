//IF (Condición) ---------------------
// if(1==10){
//     console.log("Son números iguales")
// }else{
//     console.log("Son números diferentes")
// }

//Ejemplo2
// let userName="otto";

// if(userName=="ana"){
//     console.log("Un gusto ana");
// } 
// else if(userName=="eduardo"){
//     console.log("Un gusto eduardo");
// }
// else{
//     console.log("no te conozco")
// }

//And (&&) -------------------
// let user = "admin";
// let pass = 123

// if(user == "admin" && pass==123 ){
//     console.log("bievenido")
// }else{
//     console.log("Credenciales incorrectas")
// }


// if(user="admin"){
//     if(pass=123){
//         console.log("bienvenido")
//     }
// }else{
//     console.log("Datos incorrectoss")
// }






// OR(||) ---------- 

// let user = "root"
// if(user=="admin" || user=="root" ){
//     console.log("bievenido");
// }else{
//     console.log("usuario invalido");
// }

// Operador ternario(?) ---------- 
let age = 15;
let isMajor = age>=18 ? true : false;
console.log(isMajor);