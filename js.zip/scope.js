let userName = "Eduardo global";

function sayHello(){
    let userName ="eduardo local"
    console.log("Hola "+userName);
}

sayHello();
