let userName = prompt("Hola, ¿Cómo te llamas?");

if(userName=="eduardo"){
    alert("Hola, es un gusto conocerte "+userName);
}else{
    alert("no te conozco");
}